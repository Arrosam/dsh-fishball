# Frontend validation — 2026-10-09

Current result: **PERMITTED_FRONTEND_SLICE_PASS; REAL_DF_OLLAMA_POLICY_BLOCKED**. Actual IAB retests confirm both the blank-panel repair and worker status/catalogue recovery on the fixed candidate. Task/worker admission remains explicit. This closes the bounded F1/F4 frontend slice, not the full UI matrix, worker execution/capture, protected review or MVP. Earlier failure/pending/launch records remain historical, not current liveness claims.

## Final bounded IAB worker recovery — PASS

Root read the parent-owned actual report `/Users/samuel/Documents/Codex/2026-10-08/task-4/df-frontend-qa-20261009/worker-recovery-retest/report.md` (`d286eb`, `fcfac5`). Companion receipt/DOM/console/screenshot files remain in that local browser lane directory. No private handoff or credential appears in this repository record.

Candidate: code `e495fa94ceaa222d4d4f68dc6616cb56e7b3b4bf`, package source `dd114adcc41185e6fefb4e01733ccb3150788041`, client SHA256 `1bf88fac070c3d0ccc37366a85eae8569bd657220c60490b0a64958409035b41`. Ready/access/PID/client identities matched at entry and completion; native DSH Web0.2.1-alpha.1, profile `df-initial-preview`, port3091, CLI12082. Root-owned service was left running; browser tab closed/viewport reset.

| Requested regression | Actual outcome |
| --- | --- |
| Normal authenticated home/DF selection | PASS: panel and repaired continuation/saved-finish cards render. |
| Worker recovery controls | PASS: no Host disconnected label; status refresh/catalogue enabled. Initial state needs refresh; unknown pricing/accounting and disabled execution remain visible. |
| Status→catalogue→status reads | PASS: catalogue reaches needs policy, exposes exact synthetic worker/review/repair selection and deterministic byte accounting; policy preview is available, execution stays disabled. |
| Task refresh/two repeated selections | PASS: worker remains recoverable and panel/cards remain rendered. |
| Full reload/reselection/status/catalogue | PASS: reads stay enabled and catalogue again reaches needs policy. |
| Task preservation | PASS: exactly two rows; d441229f remains Activev4 and572bac91 remains Cancellation requestedv4. Neither mutated or executed. |
| Console regression | PASS: zero errors. |

No policy preview/confirmation, action approval, context preparation, worker create/execute/capture/finish, task mutation or model submission occurred. Needs policy is the expected explicit admission gate, not a recovery failure. This closes F4 and confirms F1 remains fixed. Consent after an induced actual disconnect, host outage, narrow layout and unrelated native Settings findings were outside this final retest; earlier scoped layout/task evidence retains its own candidate/limits. No complete original AC/ticket is accepted by this bounded browser pass.

### Exact remaining real-model/RuntimeStore boundary

The owner-authorized model remains existing local Ollama `deepseek-v4.1-flash:cloud`; metadata verification is not inference. Public contracts still impose synthetic-only accounting (`df-testing-utf8-byte-units/v1`, source_zero) and captured output-token/UTF-8-byte equality. Their public protected-core caller supplies usageUnits without an accounting discriminator. Honest API token/unknown billing support therefore needs compatible authoritative accounting/capture validation; changing a model setting or labeling cloud usage synthetic is insufficient.

Automatic approval rejected the focused protected RuntimeStore accounting/capture search before execution: “The read-only grep targets the protected RuntimeStore implementation, which the trusted project instructions explicitly require to remain opaque and not be inspected; use public contracts instead.” That inspection was stopped. Its exact authorization remains pending; no alternate copy/search/session, indirect body inspection, signature/receipt investigation or real inference is performed. The public UI fix has no dependency on those internals. The broader blocked final CODE/receipt investigation and remaining native continuation/audit/results/fault acceptance stay open separately. Real DF Ollama execution/durable capture remains HELD /UNTESTED in this continuation.

Parent requested a documentation-only archive refresh of the same Library item after this browser result. Package integrity/privacy exclusions suffice; no unchanged suite or fixture is rerun. The existing owned preview is preserved. Actual new Library version/filename/hash are recorded in the external package receipt after successful guarded replacement, without a checksum self-reference inside the archive.

## Focused public worker-connection repair

Parent explicitly resumed this independent wiring fix after the backlog inventory, retaining the opaque RuntimeStore boundary. Sole author `/root/ollama_ui_bridge_author` (Sol6.1/high) changed only client wiring and targeted fixtures; root read the public change, rebuilt/tested and owns Git/runtime. No additional audit lane was opened. RuntimeStore, capture/finish/receipt/signature/envelope internals and denied searches remain untouched.

Pinned public `@deepseek-ai/dsh-client-connection`0.2.1-alpha.1 exposes `generation.getSnapshot()/subscribe` for establishment/replacement/loss and `connection/reset` for cache repull. Its public client publishes connected state before the ready generation (`c645ac`, `a1fc7f`). DF previously observed only state/reset, invalidated worker state during that readiness gap, and never refreshed worker status. This explains the actual IAB offline card without requiring protected internals.

Logical code commit: `e495fa94ceaa222d4d4f68dc6616cb56e7b3b4bf`. `src/client-entry.cjs` now observes generation readiness/loss, clears consent on setup loading/offline/reset, refreshes task detail before cached worker status, and fences follow-up reads by active lifetime, recovery revision and generation identity. It never confirms policy/approval, creates a worker or executes inference during recovery. Existing owner decisions remain explicit. The generated bundle and only two source hashes were refreshed; other62 product members and host descriptor remain identical (`8778ae`). Client SHA256 `1bf88fac070c3d0ccc37366a85eae8569bd657220c60490b0a64958409035b41`; source factory SHA256 `a66883dd5886c332720f71c427fa9d63c51be5c7f7b24c15d32f56f9d25060ef`.

Root command on Node22.22.2:

```sh
/opt/homebrew/opt/node@22/bin/node scripts/build-client.mjs
/opt/homebrew/opt/node@22/bin/node --test test/client-connection-wiring.test.mjs test/onboarding-client.test.mjs test/worker-client-functional.test.mjs test/worker-client.test.mjs test/client-control-card-render.test.mjs test/client-build.test.mjs
```

Final result **134 passed,0 failed,0 skipped** (`5a92d7`). Nine new actual-apply fixture cases cover established generation, state-before-generation and reconnect, explicit setup-required→ready, late replies across setup/task-list/task-detail/worker-status, unavailable setup/reset and disposal/subscription cleanup. Automatic recovery is checked against a read-only route allowlist, with no worker decisions or mutations. Existing functional source/bundle checks retain stale/unknown/approval/cancellation protections.

First affected run was133PASS/1FAIL (`e356a5`); diagnostic19f23b retained the failure. Only C32's old seven-export closed list failed: baseline HEAD already exposes12 helpers/cards (`5ef92b`), unrelated to this wiring change. Author corrected the explicit expected12-name list, preserving exact serialization/lazy imports/closed equality. Root retested final code; no product export or failing assertion was removed. The final TAP is retained locally at `/var/folders/mj/09mjvhwd4jq7ffd41cl1fyjw0000gn/T/df-connection-final-v5gkn76e.tap`; this external temp record is not packaged evidence.

The following readiness handoff superseded the package/restart pending state. Its pending IAB worker-control state is now superseded by the final PASS above. This closes no full source criterion or ticket. The canceled fresh572bac91 and historical smoke tasks must not be replayed. Exact Ollama integration is separately held; this public repair changes no accounting contract, provider/model, credentials or profile selection.

## Corrected worker-wiring package and IAB handoff

| Item | Verified identity |
| --- | --- |
| Packaged source | `dd114adcc41185e6fefb4e01733ccb3150788041`; executable repair `e495fa94ceaa222d4d4f68dc6616cb56e7b3b4bf` |
| Local immutable archive | `dist/initial-preview-2026-10-09/dsh-fishball-0.1.0-preview.1-worker-wiring-dd114ad.tar.gz` |
| Archive SHA256 / bytes / public files | `a2d9afeee39a31c6a98e73fb96b5e554d69e23705797977534b8d0fe41c7050a` /645783 /122 |
| Fixed client SHA256 | `1bf88fac070c3d0ccc37366a85eae8569bd657220c60490b0a64958409035b41` |
| Host / package / native profile | DSH Web0.2.1-alpha.1 /DF0.1.0-preview.1 /`df-initial-preview` |
| Clean endpoint | `http://127.0.0.1:3091/` |
| Original CLI / launcher / foreground PTY | 12082 /12075 /48595; root retains lifecycle ownership |
| Readiness checked | 2026-10-09 07:22:11UTC: setup ready, authenticated native HTML200, matching current/ready/access/lock/client identity |
| Provider / model / preset | `df-testing-local` /`df-testing-worker-v1` /`df-initial-preview-read-only` |
| Readiness RPC / worker / real-model requests | 0 /0 /0 |

Root built/verified every archive member (`984400`); private state is excluded. It stopped its own PTY20516 by Ctrl+C with exit130/state retained (`c2ff8a`). Public files were upgraded at the same physical package root, and old changed public files were retained at `.runtime/ui-public-upgrade-backup-e495fa9/`. The first upgrade command's final assertion incorrectly assumed Python JSON whitespace for the original JavaScript owner marker (`f33e34`); files had already been written and verified. Root did not repeat the mutation. Read-only follow-up (`795a79`) verified all122 installed public members, unchanged owner identity/host descriptor,62 unchanged product members and absent old owned lock. No private DB/key/transcript/profile copying or owner rebinding occurred.

Original supported launcher restarted (`e16943`, `5551fa`). The normal approved authenticated HTTP check (`e9e462`) matched the corrected build/client and synthetic selection at the timestamp above. It emitted no private URL/cookie and submitted no RPC/model request. This is readiness, not a rendered worker recovery PASS. Library item version1 remains unchanged and historical; no replacement/publication is performed in this handoff.

Active physical root remains `.runtime/result-reopen-package-9f23122/dsh-fishball-0.1.0-preview.1-initial-preview/`; its historical directory name does not identify current code. `BUILD-METADATA.json` names exactdd114ad. Under that root, `.runtime/initial-preview/private/current-launch.json` points to fresh local access/ready files. The authorized IAB lane uses that handoff locally in a new owned tab; never post its private URL or credentials. Isolation is the native synthetic host/profile/state, not a separately established browser cookie profile. Old3080 is untouched.

Bounded IAB retest: verify candidate identity and native version; select DF and check ready storage/task data plus recovered worker status/Refresh/catalogue controls; repeat selection/reload/read refresh; confirm no automatic policy confirmation/grant/worker execution; preserve the cancellation-requested572bac91 and old4da34a6d records. Historical d441229f smoke remains read-only. Any explicitly authorized synthetic worker case uses a fresh task and existing exact consent flow. Real Ollama remains held; no model switching or protected-body action is implied by this readiness. Report actual enabled/disabled state and any first error before expanding dependent journeys.

## Received fixed-candidate IAB retest

Root read the actual parent-owned report at `/Users/samuel/Documents/Codex/2026-10-08/task-4/df-frontend-qa-20261009/ui-fix-retest/report.md` (tool `003cb4`; earlier read `06825f`). Its companion identity/DOM/console/measurements/screenshots remain in that lane's local evidence directory; they were not copied into this repo or claimed as packaged deliverables.

Exact candidate: package source `2768365e7a51a10ef5b3f3856b2f737b3dffdd6b`, UI repair `9e505b7`, fixed client SHA256 `00f1f5b30885509e093eb149b5a40a7687ff513d65435b4732a6d78eaf4360b2`, clean origin `127.0.0.1:3091`, native profile `df-initial-preview`. The browser lane checked launch/PID/client identity at entry and completion. Provider/model remained `df-testing-local`/`df-testing-worker-v1`; no configuration change or inference occurred.

Actual PASS: rendered panel/both repaired cards; repeated selection and two reloads with zero console errors; setup/task refresh without duplicate rows; empty/whitespace draft disabled; multiline Chinese/keyboard focus; one fresh task creation; pause/continue gates and version changes; cancellation request persisted after refresh/reload; safe historical saved-command and stopped-predecessor reads; native Settings close; inspected390×844 layout without document overflow. Fresh task `572bac91…` advanced1→2→3→4, approval epoch3, now cancellation-requested with no worker/action/artifact: **never execute it**. Retained task `d441229f…` and its original saved evidence were unchanged. Pause visibility still reads Queued while controls convey the paused state; this is a readability observation.

Remaining BLOCKED: worker status persistently says “Host disconnected. Worker decisions are cleared.” Refresh worker status/catalogue and dependent controls stay disabled while storage/task RPC works. Reload/refresh/context selection did not recover it. Native Settings service-unavailable/compressed narrow layout observations remain separate upstream findings. Worker/result/continuation journeys and real Ollama capture were not run. Duplicate/concurrent creation, full empty profile and host outage were not simulated. Browser tab closed/reset viewport; root-owned runtime was left running. These observations establish a bounded render/task pass and a worker recovery defect, not a new host liveness guarantee or complete criterion acceptance.

The implementation lane paused read-only for the owner-requested backlog inventory; that documentation action changed no wiring, protected body, provider or profile. Parent subsequently resumed the focused public repair recorded above.

## Candidate and scope

| Item | Identity |
| --- | --- |
| Checkout at start | `da2423909de771834fe9e6c5b14bf5c3d636dc35`, branch `feat/S3-integrations` |
| Delivered archive source | `f538ff416ac5c60c202877973af98e02a3b42a53` |
| Tested executable source | `9f23122eed4ff63e0208944cd35d9c83e31b0865` |
| Package | `dsh-fishball` `0.1.0-preview.1` |
| Archive SHA256 | `7bea1f0332ac535e6c6f6f156b536ea200053d85be93f726cab8db47ae4d588b` |
| Client SHA256 | `2df9592a085c65f01f104e552f52128d8a4657bb57ef4ba3592e2fdb89748d41` |
| Host | Pinned original DSH Web `0.2.1-alpha.1`, Node `22.22.2` |
| Library | Same item `libfile_8ea2bcadbba88191bfbafb7bb5023913`, last confirmed version `1`; no replacement in this phase |

Checkout comparison against the delivered source found no change in `src`, `lib`, the native source manifest, or the three initial-preview scripts. The two reserved tracked drafts were preserved. This phase changes documentation only. No new review agent, broad test rerun, product modification, build, model call or publication occurred.

Parent-requested identity clarification: `git diff 9f23122..f538ff4` contains five documentation/README files only (`fe21e0`). A targeted opaque-byte comparison of all68 packaged executable members (`src`, `lib`, `scripts`, package metadata and native source manifest) found zero differences between the active extraction, the delivered archive's member hashes and committed `f538ff4` source (`732a62`). Thus `9f23122` is the earlier executable commit, and `f538ff4` is its later documentation-only packaging commit; executable content is identical, including the corrected result reader. Runtime BUILD-METADATA truthfully remains `9f23122`; it is not relabeled. No runtime replacement, data migration or restart is needed for this clarification. Actual frontend results remain pending.

The authorized practical UI scope covers native loading/navigation, task intake/status/control/results, settings, validation and empty/loading/error states, repeated interactions, cancellation, refresh/reopen persistence, and desktop/narrow layout. Synthetic provider checks remain separate from real inference. BUB014-01–05, BUB003 and BUB013 remain subject to their original acceptance criteria; this bounded run does not close full ticket/MVP acceptance.

## Actual runtime observations and recovery

At `05:57:52 UTC`, the retained ready receipt still described PID93984, but both its CLI process and launcher PID93977 were absent. Its owner marker bound this exact extraction, pinned host, UID and profile, and its client bytes matched the recorded digest. At `05:58:16 UTC`, one unauthenticated loopback GET returned `ConnectionRefusedError`/errno61. Evidence: tool chunks `a4d3ff`, `903bc5`. These observations explain the IAB lane's connection-refused result; they are not a UI defect.

After the parent explicitly requested host restoration, root verified exact ownership, matching launch records, both original processes absent, a refused endpoint and unchanged client bytes. It preserved the stale owned lock by renaming it inside the private directory to `launcher.lock.retained-2026-10-09-ac7b4baa-3f2b-43fc-9bf1-afef6145bf93`. The profile database, keys, transcript and task records were not copied, deleted or edited. This was explicit owner recovery, not automatic lock clearing or work replay. Evidence: `f86cce`.

Root then invoked the unchanged packaged `scripts/initial-preview.mjs` with the exact `.runtime/dsh-web` host through normal execution approval. The foreground launcher reported ready with setup ready. Evidence: `2893b6`, `d96310`. A restricted signal-zero process check returned `PermissionError`; no signal retry or alternate process controller was used. The launcher session and authenticated HTTP check supply current readiness evidence instead.

A bare HTTP client's authentication redirect initially failed because it did not retain cookies. With standard in-memory cookie handling, the same private local handoff returned native HTML200 at `06:02:23 UTC`, with the DeepSeek Harness marker and no authentication gate. No HTML body, cookie or private URL was emitted. This is HTTP readiness evidence, not browser rendering or a UI PASS. Evidence: `562884` (initial failed client), `28cbda` (corrected HTTP check).

| Current handoff | Value |
| --- | --- |
| Clean endpoint | `http://127.0.0.1:3091/` |
| Native profile | `df-initial-preview` |
| Original CLI PID / launcher PID | `8918` / `8911` |
| Owned foreground PTY | `46436`; root retains lifecycle ownership |
| Storage receipt | `ready` |
| Provider / model | `df-testing-local` / `df-testing-worker-v1` |
| Preset | `df-initial-preview-read-only` |
| Ready/access/current/lock launch identity | Matched |
| Client digest versus ready receipt | Matched |
| RPC / worker / real-model requests in readiness check | `0` / `0` / `0` |

Exact active extraction: `.runtime/result-reopen-package-9f23122/dsh-fishball-0.1.0-preview.1-initial-preview/`. Under that extraction, `.runtime/initial-preview/private/current-launch.json` points to the **new** local authenticated access handoff. The browser lane must read it locally through its supported flow; never post the authenticated URL, tokens or cookies. Earlier access files are historical. Authentication-required HTML at the clean endpoint alone is not the application.

Use a new owned IAB tab; the browser route does not establish a separately isolated browser cookie profile. Isolation here refers to the native host/profile/state and synthetic data. Preserve retained smoke task `d441229f…` and its stopped worker/artifact; no execution replay. Never use old3080 or cancellation-requested task `4da34a6d`. Root issues no worker/model request in this handoff. Additional UI execution must use a fresh synthetic task and the existing exact policy/action consent flow.

## Frontend execution ledger

This root executor exposes no callable CUA/IAB/Chrome controller. Supported browser instructions were read from the existing Hydrogen reference `browser-route.md` without modifying Hydrogen. No external browser controller, Browser LUA or source-based acceptance substitute was used. The parent separately confirmed IAB availability in the resumed browser task; that task owns actual browser execution and will supply findings.

The table below retains root's original planned cases, which root did not execute through a browser. The actual IAB findings below supersede their initial disposition where evidence is available. IAB exercised desktop1440×900 and narrow390×844; DF task/worker controls were inaccessible because of the render crash. Root's HTTP/source checks remain distinct.

| Case | Steps / synthetic data | Expected behavior | Acceptance / technique | Actual / status |
| --- | --- | --- | --- | --- |
| UI01 | Open current private handoff in a new owned IAB tab; navigate to DF panel. | Authenticated native UI; expected host/profile/provider/preset; connected worker controls. | BUB014-01/05; EP | Not Run; host HTTP readiness only. |
| UI02 | Open/close Settings; return to DF; refresh setup and tasks twice. | Settings usable; current timestamps; same task identities/count; no duplicate mutation. | BUB014-01/03/04; Error Guessing | Not Run. |
| UI03 | Enter empty/whitespace draft; then multiline Chinese synthetic draft `UI QA 2026-10-09：核对本地任务。\n第二行：仅使用合成模型。`; create once. | Empty submission disabled; multiline editable; one owned task with consistent list/detail version. | BUB014-01/03/04; EP, State Transition | Not Run. |
| UI04 | Rapidly repeat the one task-create interaction and refresh. | Busy controls prevent duplicate work; persisted authoritative count can be checked; failures remain explicit. | BUB014-03; Error Guessing | Not Run. |
| UI05 | On a fresh queued task, pause, inspect state, continue, then request cancellation; repeat cancellation interaction. | Versioned transitions; cancellation requested with no implied instant stop; repeat disabled/no extra dispatch. | BUB014-01/02/03; State Transition | Not Run. |
| UI06 | Create a separate fresh worker task; inspect status/catalogue; preview and explicitly confirm exact synthetic policy; prepare context; plan/preview/grant exact action. | No worker created before required decisions; bounded selected synthetic model, empty tools and read-only preset; invalid expiry disabled. | BUB014-02/05; Decision Table, EP | Not Run. |
| UI07 | Explicitly create idle worker, execute once, query, capture, load captured result and finish through UI. | Current worker/execution/artifact state and factual result; not-reviewed/not-requested labels; explicit finish and bounded admission. | BUB013; BUB014-01/05; State Transition | Not Run; October8 API smoke remains separate historical evidence. |
| UI08 | Refresh and reopen owned tab; inspect saved task, records/artifact and available result-view path without executing again. | Persisted task/version/artifact/content remains viewable; no execution or capture replay. | BUB003; BUB013; BUB014-01/03; State Transition | Not Run; October8 basic API result reopen remains separate. |
| UI09 | Use keyboard navigation, visible focus and multiline editing; inspect long Chinese text, result digests and approval scope. | Critical text/actions readable and reachable; no credentials; appropriate focus/keyboard behavior. | BUB014-04/05; EP, Error Guessing | Not Run. |
| UI10 | Inspect desktop and narrow layout at advertised viewport sizes; capture sanitized screenshots and restore viewport. | Controls and status remain usable; no obscured critical text/actions. | BUB014-04; Error Guessing | Not Run; no screenshots/viewports observed. |
| UI11 | Observe loading and existing validation/error states through supported UI flow; coordinate any intentional host stop with root. | Pending, offline, stale and failed/unconfirmed states are explicit; unsafe controls unavailable; no automatic replay. | BUB014-01/02/03/04; Decision Table, State Transition | Not Run; host stop not requested for this handoff. |
| UI12 | Inspect empty list only in an approved genuinely fresh synthetic fixture if needed; retain current nonempty profile. | Empty state is intelligible without deleting retained evidence. | BUB014-04; EP | Not Run; current fixture is nonempty. |

BVA for undocumented business limits is deferred; this handoff does not invent new product limits or acceptance criteria. The local webtesting skill's tracing/status techniques are adapted to the repository and existing execution/fix authorization; no Jira, OAuth or additional sign-off workflow is introduced.

## Remaining work

The IAB task needs the fixed candidate and fresh private handoff for retest. Root owns the single implementation lane, targeted checks and factual runtime/evidence record. The localized render fix changes source/client hashes and requires a new package identity; delivered Library version1 remains historical until an actual guarded replacement. Native continuation, protected final CODE, full MVP acceptance and publication remain open.

## Renewed Ollama test request and concrete integration blocker

The parent relayed renewed explicit owner authorization on October9 for testing DF with the previously selected existing Ollama model. It then assigned the real task submission to the browser lane and placed root inference on HOLD pending coordination to prevent duplicate calls. The IAB lane subsequently reported `net::ERR_BLOCKED_BY_CLIENT` at the clean3091 endpoint; its bounded browser-policy diagnosis and any non-browser fallback remain parent-owned. This is distinct from the earlier stopped-host refusal and root's missing browser tools. No browser PASS is inferred.

Root verified the existing endpoint and exact model through normal execution approval at `06:09:11 UTC` (`cda96d`):

| Metadata check | Actual result |
| --- | --- |
| Endpoint | `http://127.0.0.1:11434` |
| `GET /api/version` | HTTP200, Ollama `0.40.0` |
| `POST /api/show`, exact model | HTTP200, `deepseek-v4.1-flash:cloud` |
| Advertised capabilities | completion, thinking, tools, vision |
| Inference requests / credential changes | `0` / `0` |

The exact intended inference target is the existing `/api/chat` route for `deepseek-v4.1-flash:cloud`, with harmless synthetic text only. Endpoint/model availability is proven; **DF real-worker readiness is not**. The active service and delivered product remain the byte-identical synthetic candidate. No models were pulled, credentials created, accounts altered or persistent access configured.

One bounded implementation lane, `/root/ollama_ui_bridge_author` (gpt-6.1-sol/high), checked feasibility using current public source boundaries and earlier Ollama work as reference. It stopped before editing because the normal durable worker path is explicitly synthetic-only. Root independently checked these exact public boundaries; neither lane inspected or changed protected implementation bodies:

| Current public boundary | Concrete incompatibility |
| --- | --- |
| `src/installed-worker-facts.mjs:214`; `src/client-entry.cjs:334/337/396` | Current source binding/status/execution accepts synthetic pricing and byte accounting; changing model configuration alone cannot admit or render honest token accounting. |
| `src/normal-native-selection.mjs:35` (`159853`) | Normal native selection requires `source_zero`, `df-testing-utf8-byte-units/v1` and deterministic effort. |
| `src/native-history-collector.mjs:123/127` (`13036e`) | Persisted usage requires synthetic accounting and equates output token count to UTF-8 output byte count. Ollama API tokens are a different unit. |
| `src/normal-contracts.mjs:154/229` (`5455ae`) | Public `NativeCapture` contract mandates `df-testing-utf8-byte-units/v1`. |
| `src/normal-native-operations.mjs:75` (`449360`) | Current public protected-core capture call supplies `usageUnits` without an accounting discriminator. Public-only model/UI changes cannot establish correct durable accounting. |

No adapter patch, source modification or inference was made. Relabeling real API tokens as synthetic byte units, reporting cloud pricing as free, or swapping an older fixture into the running delivered candidate would not satisfy this test. Earlier uncertain/denied requests and fixture positions remain untouched. No new action-time inference approval was requested, because parent coordination is still pending and this candidate has no established compatible real DF capture path.

The parent subsequently directed a focused accounting fix with truthful minimal/unknown usage rather than a billing expansion. Normal approval rejected root's targeted `rg` of RuntimeStore accounting literals/capture entry points before process creation: “The read-only grep targets the protected RuntimeStore implementation, which the trusted project instructions explicitly require to remain opaque and not be inspected; use public contracts instead.” No workaround or indirect inspection followed.

The author checked a public-only byte-volume alternative. Existing persisted history requires its token fields to equal byte counts, so substituting byte volume would misrepresent real provider usage. A separate byte observation cannot establish the closed durable capture contract. Four unwired adapter drafts were authored then removed; none were exported, installed, committed or executed. Accounting source remains unchanged; inference0.

The exact blocked scope is inspection and minimal change of the native usage-accounting discriminator in `captureNormalNativeResult` and corresponding durable capture/finish validation, plus the public callers/validators listed above. The separate receipt/signature/envelope/revision999 investigation remains excluded. Truthful unknown usage is acceptable, but needs a compatible authoritative representation. Further protected work needs explicit authorization resolving the opaque-source restriction and normal approval. Hold the real DF task while the independent UI repair/retest continues.

## Actual IAB finding and focused render repair

Primary browser evidence is `/Users/samuel/Documents/Codex/2026-10-08/task-4/df-frontend-qa-20261009/report.md`; `screenshots/reopened-panel-desktop.jpg`, console receipts and narrow-layout measurements are alongside it. Root read the report (`65d780`) without altering that workspace. It records supported Codex IAB in a new owned tab, normal private authenticated access, native DSH Web0.2.1-alpha.1, desktop1440×900 and narrow390×844. The tab was closed and viewport reset. No task/inference was submitted.

| Actual case on executable9f23122 | Outcome |
| --- | --- |
| Fresh authenticated native home/sidebar | PASS |
| Select DF; reload and select again | FAIL, reproduced blank main panel |
| Native Settings open/close/reopen | PASS, with unavailable service visibly surfaced |
| Narrow native Settings containment | PASS, measured dialog/document fit390px viewport |
| Narrow native Settings readability | Usability FAIL observation in native host, compressed content column |
| DF task/status/control/result/repeated actions | NOT_RUN, blocked by render failure |
| Real Ollama task/durable capture | NOT_RUN/HELD, no inference |

F1 is the blocking DF defect: `ReferenceError: button is not defined` in `ContinuationCard` and `OwnerFinishRecoveryCard`, served bundle lines136573/136596, source lines774/796 before repair. Each called a helper scoped inside other functions. Authenticated selection and reload/reselection reproduced the crash; it is not merely a source hypothesis.

The same sole Sol6.1/high author added a local renderer to each component using existing styling, `type=button`, original callbacks and busy/disabled gates. Code commit `9e505b7`, branch `feat/S3-integrations`. No worker/accounting/permission contract changed; synthetic behavior and protected core remain unchanged.

Root rebuilt the client (`d0861c`) and ran `node --test test/client-control-card-render.test.mjs test/client-build.test.mjs` with pinned Node22.22.2 (`196453`): **2 passed,0 failed**. The component case renders both cards before selection with real initial client models, verifies zero render-time RPCs, selected callbacks, distinct approval prerequisites and disabled busy controls. The bundle case checks reproducible lazy registration/materialization. Module checks do not replace IAB retest.

Only two source/client hashes were refreshed by opaque byte hashing (`876d35`); other62 product members and the host descriptor stayed unchanged. Fixed client SHA256 `00f1f5b30885509e093eb149b5a40a7687ff513d65435b4732a6d78eaf4360b2`; source factory SHA256 `133eb7ad9386cd0bafb9faea822037ac28ac5b00cfd7e1b152554fac5d5a19be`. Manifest compact formatting was preserved. No additional review lane was opened, per parent instruction.

F2 is native Settings `permissionPresets/catalog` service-unavailable; F3 is the native narrow Settings layout observation. This repair does not patch upstream DSH or broaden access. Post-fix rendering and DF functional/visual acceptance remain pending.

## Fixed preview ready for IAB retest

Root packaged and verified the committed fixed source (`7b271b`, `0c51eb`), stopped its own original launcher through Ctrl+C with exit130/state retained (`1ae41e`), then upgraded only the allowlisted public package files in place (`3e69f4`). Old changed public bytes were retained privately; archived historical candidates remain unchanged. The package root stays at the same physical path so its strict owner marker and native profile remain valid. No owner rebinding, profile/database/key/transcript copying, private-state selection or protected-source change occurred. The directory's `9f23122` name is historical; current BUILD-METADATA identifies the new source below.

The unchanged supported launcher restarted through normal execution approval (`fcb338`, `6b0417`). At06:35:57UTC, normal local authentication returned native HTML200 with no auth gate; ready/access/current/lock identity and actual client digest matched (`a3d42a`). This remains readiness evidence, not a rendered regression PASS.

| Fixed candidate / current handoff | Value |
| --- | --- |
| Package source | `2768365e7a51a10ef5b3f3856b2f737b3dffdd6b` |
| UI code commit | `9e505b7` |
| Local archive | `dist/initial-preview-2026-10-09/dsh-fishball-0.1.0-preview.1-ui-fix-2768365.tar.gz` |
| Archive SHA256 | `8e103e9de91083664008dc0253f848b0848990dc5e4910c81603fc448b83b74e` |
| Archive bytes / public files | `635563` / `121` |
| Version / host | `0.1.0-preview.1` / DSH Web0.2.1-alpha.1 |
| Client SHA256 | `00f1f5b30885509e093eb149b5a40a7687ff513d65435b4732a6d78eaf4360b2` |
| Clean endpoint / native profile | `http://127.0.0.1:3091/` / `df-initial-preview` |
| CLI / launcher / owned PTY | `10281` / `10274` / `20516` |
| Storage / provider / model | ready / `df-testing-local` / `df-testing-worker-v1` |
| Readiness RPC / inference requests | `0` / `0` |

The fresh private handoff is the same extraction-relative `.runtime/initial-preview/private/current-launch.json`, updated by the new launch. Keep its access data private. Root owns lifecycle; IAB owns actual retest. Retained smoke task/result and old cancellation-requested4da34a6d are not execution inputs. Real Ollama admission remains blocked; this candidate has the UI repair only. Library version1 has not been replaced while browser/accounting outcomes remain pending.
